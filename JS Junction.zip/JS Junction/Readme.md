# JS Junction – Brewed Projects

Welcome to **JS Junction**, a showcase of my JavaScript projects brewed with creativity and precision. This repository highlights a collection of interactive and visually appealing web applications, each crafted with a unique purpose and design.

## 🌟 Live Demo
Visit the live demo: [JS Junction](https://krish2248.github.io/JS-Junction/)

---

## 📂 Project Overview

### 1. **Vellum-Codex**
   - **Description**: A beautifully crafted digital library showcasing my personal book collection.
   - **Tech Stack**: HTML, CSS, JavaScript
   - **Links**: [GitHub](https://github.com/krish2248/Vellum-Codex) | [Live Demo](https://krish2248.github.io/Vellum-Codex/)

### 2. **Multi-Purpose-Calculator**
   - **Description**: A versatile calculator app with multiple functionalities like BMI, EMI, and car loan calculations.
   - **Tech Stack**: HTML, CSS, JavaScript
   - **Links**: [GitHub](https://github.com/krish2248/Multi-Purpose-Calculator) | [Live Demo](https://krish2248.github.io/Multi-Purpose-Calculator/)

### 3. **Text-Adventure-Game**
   - **Description**: A browser-based interactive storytelling game with multiple storylines and outcomes.
   - **Tech Stack**: HTML, CSS, JavaScript
   - **Links**: [GitHub](https://github.com/krish2248/Text-Adventure-Game) | [Live Demo](https://krish2248.github.io/Text-Adventure-Game/)

### 4. **Tic-Tac-Toe**
   - **Description**: A fun and interactive Tic Tac Toe game with responsive design, dark mode, and score tracking.
   - **Tech Stack**: HTML, CSS, JavaScript
   - **Links**: [GitHub](https://github.com/krish2248/Tic-Tac-Toe) | [Live Demo](https://krish2248.github.io/Tic-Tac-Toe/)

### 5. **Dice**
   - **Description**: A web app for rolling dice, designed for tabletop games like Dungeons & Dragons.
   - **Tech Stack**: HTML, CSS, JavaScript
   - **Links**: [GitHub](https://github.com/krish2248/Dice) | [Live Demo](https://krish2248.github.io/Dice/)

### 6. **Rock-Paper-Scissors-Lizard-Spock**
   - **Description**: A modern implementation of the classic game with offline and online multiplayer modes.
   - **Tech Stack**: React, Redux, TypeScript, Socket.IO
   - **Links**: [GitHub](https://github.com/krish2248/Rock-Paper-Scissors-Lizard-Spock) | [Live Demo](https://github.com/krish2248/Rock-Paper-Scissors-Lizard-Spock)

### 7. **Real-Estate-Management-System**
   - **Description**: A platform for buyers, sellers, and agents to coordinate and find the best deals.
   - **Tech Stack**: MySQL, PHP
   - **Links**: [GitHub](https://github.com/krish2248/REMS) | [Live Demo](https://github.com/krish2248/REMS)

### 8. **Workmate**
   - **Description**: A platform for student startups to find like-minded collaborators and thrive.
   - **Tech Stack**: In Progress
   - **Links**: [GitHub](https://github.com/krish2248/Workmate-In-Progress) | [Live Demo](https://github.com/krish2248/Workmate-In-Progress)

---

## 📜 License
This project is licensed under the [Apache License 2.0](LICENSE).

---

## Connect with Me
- **GitHub**: [krish2248](https://github.com/krish2248)
- **LinkedIn**: [Krish Soni](https://www.linkedin.com/in/krish-soni-460932228/)
- **Medium**: [@sonikrish2248](https://medium.com/@sonikrish2248)
- **Instagram**: [@notkrish03](https://www.instagram.com/notkrish03/)
- **Portfolio**: [sonikrish.com](https://sonikrish.com/)

Feel free to explore, fork, and contribute to this repository!